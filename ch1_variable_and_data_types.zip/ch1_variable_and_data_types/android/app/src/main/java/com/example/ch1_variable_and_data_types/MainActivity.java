package com.example.ch1_variable_and_data_types;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
